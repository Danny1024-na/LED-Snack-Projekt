import ledControl.BoardController;

public class EineWeitereKlasse {
	//Von UmbennnenMain übergebener Boardcontroller
	private BoardController controller;
	private static int levelnumber=1;
	private static int punkteZahl=0;
	private int SchlangeGrosse=2; //der Kopf und noch ein St�ck
	
	//Konstruktor
		public EineWeitereKlasse(BoardController controller) {
			this.controller = controller;
			BordZeichnen();
			
			//start der Schlange Oben Links
			
			
			
		}
		
		//der Anzahl von Snack gefrressenen Punkte 
		private void punkteZahl()
		{
			punkteZahl++;
		}
		
		//muss "level number" um 1 erh�hen, falls der Nutzer eine bestimmte Zahl von Punkte erreicht
		private void levelCheek()
		{
			levelnumber++;
		}
		
		
		//bewegung (nur nach rechts und links)
		private void bewegungsfunktion()
		{
			
		}
		
		//Bord muss Wei� umgeben 
		private void BordZeichnen()
		{
			
		}
		
		
		//game over : Kopf mit wei�er Wand oder mit sich selbst kollidiert 
		private void EndedesSpieles()
		{
			
		}
		
		//in einer bestimmten Zeit muss das Essen (Ein gef�rbter Punkt ) aufploppen
		private void EssenAufploppen()
		{
			
		}
		
		//sobald die Schlange etwas isst ,muss sie l�nger sein werden
		private void Schlangeverl�ngern()
		{
			
		}
		
}
