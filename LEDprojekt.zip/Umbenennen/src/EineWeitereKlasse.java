import ledControl.BoardController;

public class EineWeitereKlasse {
	//Von UmbennnenMain übergebener Boardcontroller
	private BoardController controller;
	
	//Konstruktor
		public EineWeitereKlasse(BoardController controller) {
			this.controller = controller;
		}
}
